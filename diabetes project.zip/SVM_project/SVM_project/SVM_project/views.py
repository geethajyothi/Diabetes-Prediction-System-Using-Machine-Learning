from django.shortcuts import render, redirect
import pandas as pd
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load the dataset and train models
data = pd.read_csv(r"C:\Users\geeth\OneDrive\Documents\diabetes.csv")

X = data.drop("Outcome", axis=1)
Y = data['Outcome']
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

# Train models
lr_model = LogisticRegression(max_iter=1000)
lr_model.fit(X_train, Y_train)

svm_model = SVC()
svm_model.fit(X_train, Y_train)

rf_model = RandomForestClassifier()
rf_model.fit(X_train, Y_train)

def home(request):
    return render(request, 'home.html')

def predict(request):
    return render(request, 'predict.html')

def result(request):
    if request.method == 'POST':
        try:
            val1 = float(request.POST['n1'])
            val2 = float(request.POST['n2'])
            val3 = float(request.POST['n3'])
            val4 = float(request.POST['n4'])
            val5 = float(request.POST['n5'])
            val6 = float(request.POST['n6'])
            val7 = float(request.POST['n7'])
            val8 = float(request.POST['n8'])

            input_data = [val1, val2, val3, val4, val5, val6, val7, val8]
            input_data_reshaped = [input_data]  # Reshape input data for prediction

            # Make predictions with all models
            lr_pred = lr_model.predict(input_data_reshaped)[0]
            svm_pred = svm_model.predict(input_data_reshaped)[0]
            rf_pred = rf_model.predict(input_data_reshaped)[0]

            # Determine final result by majority vote
            predictions = [lr_pred, svm_pred, rf_pred]
            final_prediction = max(set(predictions), key=predictions.count)

            result1 = "POSITIVE" if final_prediction == 1 else "NEGATIVE"

            return render(request, "predict.html", {"result2": result1})

        except KeyError:
            error_message = "Some form fields are missing. Please fill out all fields."
            return render(request, "predict.html", {"error_message": error_message})

    # Handle cases where request method is not POST
    return render(request, 'predict.html')

def custom_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            # Check if user with provided username exists
            if User.objects.filter(username=username).exists():
                # User exists, but provided password is incorrect
                error_message = "Invalid password. Please try again."
            else:
                # User does not exist, create a new user
                User.objects.create_user(username=username, password=password)
                # Optionally, you can log in the user immediately
                user = authenticate(username=username, password=password)
                login(request, user)
                return redirect('home')
    return render(request, 'login.html')

def medications(request):
    return render(request, 'medications.html')

def about(request):
    return render(request, 'about.html')

def progress_chart(request):
    return render(request, 'progress_chart.html')
